#!/bin/bash

set -e
set -o pipefail

if [[ "$1" = "--first-run" ]]; then
	# copy sources to VM
	echo "Installing SRPM..."
	rpm -ivh /vagrant/stbgcc-4.8-*.src.rpm
fi

VERSION="$(rpm -q --info --queryformat %{VERSION} \
	--specfile $HOME/rpmbuild/SPECS/stbgcc-4.8.spec)"
RELEASE="$(rpm -q --info --queryformat %{RELEASE} \
	--specfile $HOME/rpmbuild/SPECS/stbgcc-4.8.spec)"
FULLVERSION="$VERSION-$RELEASE"

## build rpm
echo -n "Building RPM..."
pushd $HOME/rpmbuild >/dev/null
rpmbuild -ba --nodeps --define '_tmppath /tmp' \
	SPECS/stbgcc-${VERSION}.spec 2>&1 | tee BUILD/buildlog
popd >/dev/null

# make tarball
echo -n "Making tarball..."
pushd $HOME/rpmbuild/BUILD >/dev/null
rpm2cpio < ../RPMS/i386/stbgcc-${FULLVERSION}.i386.rpm | cpio -id
fakeroot tar -C opt/toolchains -jcf stbgcc-${FULLVERSION}.tar.bz2 stbgcc-${FULLVERSION}
rm -rf opt
popd >/dev/null

# move toolchain to shared directory
echo "Moving resulting files to shared dir..."
rm -rf /vagrant/out
mkdir -p /vagrant/out
mv -v $HOME/rpmbuild/BUILD/stbgcc-4.8-*.tar.bz2 /vagrant/out
mv -v $HOME/rpmbuild/RPMS/*/stbgcc-4.8-*.rpm /vagrant/out
mv -v $HOME/rpmbuild/SRPMS/stbgcc-4.8-*.src.rpm /vagrant/out

echo "Toolchain build complete!"
