#!/usr/bin/env bash

apt-get update
apt-get install -y bison flex gawk install-info ncurses-dev pkg-config texinfo

# user setup

cd /home/vagrant

mkdir -p /home/vagrant/rpmbuild/{BUILD,RPMS,SOURCES,SPECS,SRPMS}
echo '%_topdir %(echo $HOME)/rpmbuild' > /home/vagrant/.rpmmacros

chown -R vagrant.vagrant /home/vagrant
